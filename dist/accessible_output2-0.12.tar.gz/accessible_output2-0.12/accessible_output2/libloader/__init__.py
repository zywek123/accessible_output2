from accessible_output2.libloader.libloader import *

__version__ = 0.1
__author__ = 'Christopher Toth <q@q-continuum.net>'
__doc__ = """
Quickly and easily load shared libraries from various platforms. Also includes a libloader.com module for loading com modules on Windows.
"""
